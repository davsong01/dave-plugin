# Sample Plugin

Full list of sections and features to build

* Modular Administration Area
* Custom Post Type Manager
* Custom Taxonomy Manager
* Widget to Upload and Display Media in sidebars
* Post and Pages Gallery integration
* Testimonial section: Commner in the frontend, Admins can approve comments, select which comments to display
* Custom templates sections
* Ajax based Login/Register system
* Membership protected area
* Chat system